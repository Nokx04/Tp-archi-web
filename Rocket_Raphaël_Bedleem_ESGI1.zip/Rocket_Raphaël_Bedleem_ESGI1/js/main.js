'use strict';

/***********************************************************************************/
/* *********************************** DONNEES *************************************/
/***********************************************************************************/

// Initialisation des variables globales
let rebours = 9; // Valeur de départ du compte à rebours (affiché 10 au début)
let compteRebours = document.querySelector('span'); // Élément d'affichage du compte à rebours
let button = document.getElementById('firing-button'); // Bouton de mise à feu
let intervalId; // Identifiant de l'intervalle pour le compte à rebours
let rocket = document.getElementById('rocket'); // Image de la fusée
let stopButton = document.getElementById('stop-button'); // Bouton d'annulation
let resetButton = document.getElementById('reset-button'); // Bouton de reset
let active = true; // Indique si le bouton de mise à feu est actif
let ignition = false; // Indique si la fusée à décoller


/***********************************************************************************/
/* ********************************** FONCTIONS ************************************/
/***********************************************************************************/

// Fonction appelée chaque seconde pour gérer le compte à rebours
function CompteARebours() {
    if (rebours < 0) {
        // Fin du compte à rebours : arrêt, décollage, changement d'image, désactivation du stop
        clearInterval(intervalId);
        ignition = true;
        rocket.src = "images/rocket3.gif";
        rocket.classList.add('tookOff');
        stopButton.disabled = true;
        stopButton.className = "disabled";
    } else {
        // Affiche la valeur courante et décrémente
        compteRebours.textContent = rebours;
        rebours--;
    }
}

// Ajoute nb étoiles de tailles et positions aléatoires sur la page
function ajouterEtoiles(nb) {
    const tailles = ['tiny', 'normal', 'big'];
    const largeur = window.innerWidth;
    const hauteur = window.innerHeight - 400; // Limite la hauteur pour éviter la zone basse

    for (let i = 0; i < nb; i++) {
        const star = document.createElement('div');
        star.classList.add('star');
        star.classList.add(tailles[Math.floor(Math.random() * tailles.length)]);
        star.style.left = Math.random() * largeur + 'px';
        star.style.top = Math.random() * hauteur + 'px';
        document.body.appendChild(star);
    }
}


/************************************************************************************/
/* ******************************** CODE PRINCIPAL **********************************/
/************************************************************************************/

// Initialisation de l'affichage et des boutons
compteRebours.textContent = 10;
stopButton.className = "disabled";
stopButton.disabled = true;
resetButton.style.display = 'none';
ajouterEtoiles(150); // Génère les étoiles

// Gestion du clic sur le bouton de mise à feu
button.addEventListener('click', function() {
    if (active){
        button.className = "disabled";
        button.disabled = true;
        stopButton.className = "enabled";
        stopButton.disabled = false;
        intervalId = setInterval(CompteARebours, 1000); // Lance le compte à rebours
        active = false;
        rocket.src = "images/rocket2.gif"; // Change l'image de la fusée
        rocket.style.width= '220px';
        rocket.style.height= '548px';
        stopButton.classList.remove('hidden');
        resetButton.style.display = 'none';
    }
});

// Gestion du clic sur le bouton d'annulation
stopButton.addEventListener('click', function() {
    if (!ignition) {
        clearInterval(intervalId); // Arrête le compte à rebours
        button.className = "enabled";
        button.disabled = false;
        stopButton.className = "disabled";
        stopButton.disabled = true;
        active = true;
        rocket.src = "images/rocket1.png"; // Remet l'image initiale
        resetButton.style.display = 'flex'; // Affiche le bouton reset
    }
})

// Gestion du clic sur le bouton reset
resetButton.addEventListener('click', function() {
    clearInterval(intervalId); // Arrête le compte à rebours
    rebours = 9;
    compteRebours.textContent = 10;
    button.className = "enabled";
    button.disabled = false;
    stopButton.className = "disabled";
    stopButton.disabled = true;
    active = true;
    ignition = false;
    rocket.src = "images/rocket1.png"; // Remet l'image initiale
    resetButton.style.display = 'none'; // Cache le bouton reset
});