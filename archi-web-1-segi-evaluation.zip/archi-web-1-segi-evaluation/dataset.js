let token = "";
async function getToken() {
    const res = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                "email": "votre@mail.com",
                "password": "votreMotDePasse"
            })
        }
    )


    let data = await res.json();
    token = data.token;
    console.log(token);
}

const categories = [
    'Électronique',
    'Vêtements',
    'Maison & Jardin',
    'Sports & Loisirs',
    'Livres',
    'Alimentation',
    'Beauté & Santé',
    'Automobile'
];
async function createCategory() {

    for (const categoryName of categories){
        const res = await fetch('http://localhost:3000/categories', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + token
            },
            body: JSON.stringify({ name: categoryName })
        });
    }
}

const produits = [
    'Décapeur Thermique',
    'Pull',
    'Décoration',
    'Football',
    'Harry Potter',
    'Bière',
    'maquillage',
    'Ford'
];

let categoryId = 1;
async function createProduct() {

    for (const productName of produits){
        const res = await fetch('http://localhost:3000/produits', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + token
            },
            body: JSON.stringify({ name: productName, categoryId: categoryId })
        });
        categoryId++;
    }
}

async function getCategories() {
    const res = await fetch('http://localhost:3000/categories', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    let data = await res.json();
    console.log(data);
    displayCategories(data);
}

function displayCategories(data) {
    const listeCategories = document.querySelector('#liste-categories');
    listeCategories.innerHTML = ''; // Clear the list before adding new items

    data.forEach(category => {
        const li = document.createElement('li');
        li.textContent = category.name;
        listeCategories.appendChild(li);
    });
}

async function getProduct() {
    const res = await fetch('http://localhost:3000/produits', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    let data = await res.json();
    console.log(data);
    displayProducts(data);
}

function displayProducts(data) {
    const listeProduits = document.querySelector('#liste-produits');
    listeProduits.innerHTML = ''; // Clear the list before adding new items

    data.forEach(produit => {
        const li = document.createElement('li');
        li.textContent = produit.name + " appartient à la catégories " + produit.categoryId;
        listeProduits.appendChild(li);
    });
}

async function createDataSet() {

    await getToken();
    await createCategory();
    await getCategories();
    await createProduct();
    await getProduct();
}

createDataSet();

document.querySelector('#addProduct').addEventListener('click', async function () {
    const productName = document.querySelector('#productName').value;
    const categoryId = document.querySelector('#categoryId').value;
    const listeProducts = document.querySelector('#liste-produits');
        const res = await fetch('http://localhost:3000/produits', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + token
            },
            body: JSON.stringify({ name: productName, categoryId: Number.parseInt(categoryId) })
        });
    let data = res.json();

    data.then(category => {
        const li = document.createElement('li');
        li.textContent = category.name + " appartient à la catégorie " + category.categoryId;
        listeProducts.appendChild(li);
    });
});