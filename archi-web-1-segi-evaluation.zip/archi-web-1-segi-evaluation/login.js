function createUser() {
    const email = "votre@mail.com";
    const password = "votreMotDePasse";
    const res = fetch('http://localhost:3000/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
}

createUser();

button_login = document.querySelector('#login')

button_login.addEventListener('click', function() {
    const email = document.querySelector('#email').value;
    const password = document.querySelector('#password').value;

    fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.token) {
            window.location.href = 'index.html';
        } else {
            alert('Identifiants incorrects');
        }
    });
});
